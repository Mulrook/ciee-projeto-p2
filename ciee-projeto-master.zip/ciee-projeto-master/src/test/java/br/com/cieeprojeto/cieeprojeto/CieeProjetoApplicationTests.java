package br.com.cieeprojeto.cieeprojeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CieeProjetoApplicationTests {

	@Test
	void contextLoads() {
	}

}
