package br.com.cieeprojeto.cieeprojeto.repository;

public class RegistrationRepositoryTest {

}
