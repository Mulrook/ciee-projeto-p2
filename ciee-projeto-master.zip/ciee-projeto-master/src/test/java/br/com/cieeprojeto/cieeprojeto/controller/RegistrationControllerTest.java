package br.com.cieeprojeto.cieeprojeto.controller;

public class RegistrationControllerTest {
}
