package br.com.cieeprojeto.cieeprojeto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CieeProjetoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CieeProjetoApplication.class, args);
	}

}
